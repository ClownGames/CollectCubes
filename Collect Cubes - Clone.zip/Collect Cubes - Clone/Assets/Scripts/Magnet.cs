﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;

/// <summary>
/// move the balls centripetally <smoothly
/// </summary>
public class Magnet : MonoBehaviour
{
    public float smooth=0.1f;

    private CubeManager cubeManager;
    
    [Inject]
    public void Installer(CubeManager cubeManager)
    {
        this.cubeManager = cubeManager;
    }

    /// <summary>
    /// When a cube enter to the collider, pull it toward to center
    /// </summary>
    /// <param name="col"></param>
    private void OnTriggerEnter(Collider col)
    {
        if (col.CompareTag("Cube"))
        { 
            col.GetComponent<Cube>().MoveTarget(transform, smooth);
            cubeManager.CountBall();
        }
    } 


}
