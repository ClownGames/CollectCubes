﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using Zenject;
/// <summary>
/// Manage the levels
/// Load, restart, Next
/// </summary>
public class LevelManager : MonoBehaviour
{
    #region Private Variables
    private PoolManager poolManager;
    private GameManager gameManager;
    private CubeManager cubeManager;
    private UIManager uIManager;
    private int level = 0;
    private Texture2Color texture2Color = new Texture2Color();
    #endregion

    #region public Variables
    public List<Texture2D> textureList = new List<Texture2D>();
    #endregion


    [Inject]
    private void Installer(GameManager gameManager, PoolManager poolManager, CubeManager cubeManager, UIManager uIManager)
    {
        this.gameManager = gameManager;
        this.poolManager = poolManager;
        this.cubeManager = cubeManager;
        this.uIManager = uIManager;

    }
     
    /// <summary>
    /// Load the level
    /// </summary>
    public void LoadLevel(){ 
        cubeManager.PrepareLevel(texture2Color.GetColorList(textureList[level]));
         
    }

    /// <summary>
    /// Called when level completed (by cubeManager)
    /// </summary>
    public void LevelCompleted()
    {
        uIManager.OpenStageClearPanel();
    }


    /// <summary>
    /// Load NextLevel
    /// </summary>
    public void NextLevel()
    {
        level = (int)Mathf.Repeat(++level, textureList.Count);
 
        PrepareGameforNextLevel();
        LoadLevel();
    }

    /// <summary>
    /// Reset level obj.s
    /// </summary
    private void PrepareGameforNextLevel()
    {
        gameManager.character.ResetPosition(); 
    }

    /// <summary>
    /// Restart the loaded level.
    /// </summary>
    public void RestartLevel()
    {
        PrepareGameforNextLevel();
        LoadLevel();
    }


}
