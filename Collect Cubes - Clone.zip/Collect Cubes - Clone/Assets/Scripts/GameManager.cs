﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;
/// <summary>
/// Manage the game
/// Initialize
/// </summary>
public class GameManager : MonoBehaviour
{
    #region privateVariables
    private PoolManager poolManager;
    private LevelManager levelManager;

    #endregion

    #region Public Variables 
    public List<PoolableObject> poolableObjectList = new List<PoolableObject>();
    public GameObject cubePrefab;
    public Character character;
    #endregion


    /// <summary>
    /// Inje.
    /// </summary>
    /// <param name="poolManager"></param>
    /// <param name="levelManager"></param>
    [Inject]
    private void Installer(PoolManager poolManager, LevelManager levelManager)
    {
        this.poolManager = poolManager;
        this.levelManager = levelManager;
    }

    private void Start()
    {
        InitializeGame();
    }

    /// <summary>
    /// Initialize the game.
    /// Pooling and loadLevel
    /// </summary>
    private void InitializeGame()
    {
        Pooling();
        levelManager.LoadLevel();
    }

    /// <summary>
    /// Pool the poolable objects
    /// </summary>
   private void Pooling()
   {
       foreach (PoolableObject pO in poolableObjectList)
       {
           poolManager.Pool(pO);
       } 
   }


}
