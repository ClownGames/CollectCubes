﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Cube Objects
/// </summary>
public class Cube : MonoBehaviour
{
    /// <summary>
    /// material of the mesh(this cube)
    /// </summary>
    public Material material;

    /// <summary>
    /// Velocity that used for smootDamp
    /// </summary>
    private Vector3 velocity;


    /// <summary>
    /// Move to target smoothly
    /// After moving make disable the cube
    /// </summary>
    /// <param name="target"></param>
    /// <param name="smooth"></param>
    public void MoveTarget(Transform target, float smooth)
    {
        StartCoroutine(MoveTargetPosition(target, smooth));
        MakeInactive();
    }

    /// <summary>
    /// Set the color of material
    /// </summary>
    /// <param name="color"></param>
    public void SetColor(Color color)
    {
        GetComponent<MeshRenderer>().material = new Material(material);
        GetComponent<MeshRenderer>().material.color = color;
        MakeActive();
    }

    /// <summary>
    /// Make the cube a active one
    /// </summary>
    private void MakeActive()
    {
        GetComponent<Collider>().isTrigger = false;
        GetComponent<Rigidbody>().isKinematic = false;
        transform.rotation = Quaternion.identity;
    }
    /// <summary>
    /// Make the cube a inactive one
    /// Color(1f,0.5f,0) is orange
    /// </summary>
    private void MakeInactive()
    {
        GetComponent<Collider>().isTrigger = true;
        GetComponent<Rigidbody>().isKinematic = true;
        GetComponent<MeshRenderer>().material.color = new Color(1f,0.5f,0);
    }

    /// <summary>
    /// go to target position
    /// </summary>
    /// <param name="target"></param>
    /// <param name="smooth"></param>
    /// <returns></returns>
    IEnumerator MoveTargetPosition(Transform target, float smooth)
    {
        while (Vector3.Distance(target.position,transform.position)>0.1f)
        {
            transform.position = Vector3.SmoothDamp(transform.position, target.position, ref this.velocity, smooth);
            yield return null;
        }
        gameObject.SetActive(false);
    }

    private void OnDisable(){
        StopAllCoroutines();
    }

}
