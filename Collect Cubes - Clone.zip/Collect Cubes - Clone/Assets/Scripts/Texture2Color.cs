﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
public class Texture2Color : MonoBehaviour
{ 
    public List<Color> GetColorList(Texture2D texture)
    {
        return texture.GetPixels().ToList();
    }
     

}
