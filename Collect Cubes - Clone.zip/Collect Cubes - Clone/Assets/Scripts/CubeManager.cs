﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using Zenject;

/// <summary>
/// Manage the cubes
/// </summary>
public class CubeManager : MonoBehaviour
{
    #region privateVariables
    private PoolManager poolManager;
    private GameManager gameManager;
    private LevelManager levelManager;

    private List<GameObject> cubeList; //Pooled
    private List<Color> colorList = new List<Color>();// list of colors(texture colors)
    private int pixelCount;// 1024 for 32x32

    private int targetCubeCount;    //equals visible pixels
    private int currentCubeCount = 0;   //collected balls

    #endregion
    #region public Variables
    public float Spacing; //space between two cube
    #endregion

    /// <summary>
    /// Injection method
    /// </summary>
    /// <param name="gameManager"></param>
    /// <param name="poolManager"></param>
    /// <param name="levelManager"></param>
    [Inject]
    private void Installer(GameManager gameManager, PoolManager poolManager,LevelManager levelManager)
    {
        this.gameManager = gameManager;
        this.poolManager = poolManager;
        this.levelManager = levelManager;
    }

    /// <summary>
    /// Prepare the level to start the game
    /// Set Color of cubes and set position of cubes
    /// </summary>
    /// <param name="colors"></param>
    public void PrepareLevel(List<Color> colors)
    {
        pixelCount = colors.Count;

        if (cubeList == null)
        {
            cubeList = poolManager._awailableGameObjectsDict[gameManager.cubePrefab].ToList();
        }

        ResetCubeList();
        this.colorList = colors;

        currentCubeCount = 0;
        targetCubeCount = 0;
        SetCubes();
    }

    /// <summary>
    /// Prepare the level to start the game
    /// Set Color of cubes and set position of cubes
    /// Like a grid system?layout
    /// </summary>
    private void SetCubes()
    {
        int x = (int) Mathf.Sqrt(pixelCount); 
        Vector3 pos = Vector3.zero;
         
        int i = 0;

        for (int s = 0; s < x; s++)
        {
            for (int p = 0; p < x; p++)
            {
                if (i < pixelCount)
                {
                    float pOffset = (float)p * (Spacing);
                    float sOffset = (float)s * (Spacing);

                    pos.x = pOffset;
                    pos.z = sOffset;
                
                    if (!CheckTransparent(colorList[i]))
                    {
                        cubeList[i].SetActive(true);
                        cubeList[i].GetComponent<Cube>().SetColor(colorList[i]);
                        cubeList[i].transform.localPosition = pos;
                        targetCubeCount++;
                    }
                    i++;
                }
            }
        }

    }

    /// <summary>
    /// Check the pixel transparent or not
    /// </summary>
    /// <param name="color"></param>
    /// <returns></returns>
    private bool CheckTransparent(Color color)
    { 
        return color.a < 0.2f; 
    }

    /// <summary>
    /// Make inactive the cubes that active ones
    /// </summary>
    private void ResetCubeList()
    {
        foreach (GameObject cube in cubeList.Where(cube => cube.activeSelf))
        {
            cube.SetActive(false);
        }
    }

    /// <summary>
    /// Count the collected balls oneByone
    /// </summary>
    public void CountBall()
    {
        currentCubeCount++;
        CheckLevelComplete();
    }

    /// <summary>
    /// Check level completed or not
    /// if collected ball count equals target, level is completed
    /// </summary>
    private void CheckLevelComplete()
    {  
        if (currentCubeCount >= targetCubeCount)
        {
            levelManager.LevelCompleted();
        }
    }
}
