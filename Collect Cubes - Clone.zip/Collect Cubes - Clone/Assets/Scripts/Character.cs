﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{

    /// <summary>
    /// Character try to move this position
    /// </summary>
    public Transform moveTarget;

    /// <summary>
    /// Start position of character (at the beginnig)
    /// </summary>
    private Vector3 startPos;

    private void Start()
    {
        startPos = moveTarget.position;
    }

    /// <summary>
    /// Reset the position to start pos.
    /// </summary>
    public void ResetPosition()
    {
        transform.position = startPos;
        moveTarget.position = startPos;
    }

}
