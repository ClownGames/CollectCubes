﻿using System;
using UnityEngine;
 
    [Serializable]
    public class PoolableObject
    {     
        public GameObject ItemPrefab; 
        public int PoolSize; 
        public Transform parent;

        public PoolableObject(GameObject itemPrefab, int poolSize,Transform parent=null)
        {
            this.ItemPrefab = itemPrefab;
            this.PoolSize = poolSize;
            this.parent = parent;
        }
        public PoolableObject(GameObject itemPrefab, int poolSize)
        {
            this.ItemPrefab = itemPrefab;
            this.PoolSize = poolSize;
            GameObject tempParent = new GameObject();
            tempParent.name = itemPrefab.name + " Parent";
            this.parent = tempParent.transform;
        }
    
    } 