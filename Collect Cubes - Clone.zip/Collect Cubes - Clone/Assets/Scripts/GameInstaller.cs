﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Zenject;


namespace Injection
{
    /// <summary>
    /// Game Installer = using for injection
    /// </summary>
    public class GameInstaller : MonoInstaller
    {

        public GameManager _gameManager;
        public LevelManager _levelManager;
        public Character _character;   
        public PoolManager _poolManager;   
        public UIManager _uIManager;
        public CubeManager _cubeManager;

        public override void InstallBindings()
        {
            Container.BindInstance<GameManager>(_gameManager);
            Container.BindInstance<LevelManager>(_levelManager); 
            Container.BindInstance<PoolManager>(_poolManager);
            Container.BindInstance<UIManager>(_uIManager);
            Container.BindInstance<CubeManager>(_cubeManager);
        }


    }
}
