﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;
/// <summary>
/// Manage the UI. 
/// Open close stage clear Panel
/// Restart and next level button actions
/// </summary>
public class UIManager : MonoBehaviour
{

    private LevelManager levelManager;

    public GameObject stageCompletedPanel;

    [Inject]
    private void Installer(LevelManager levelManager)
    {
        this.levelManager = levelManager;
    }

    public void OpenStageClearPanel()
    {
        stageCompletedPanel.SetActive(true);
    }

    /// <summary>
    /// Load next Level
    /// </summary>
    public void NextLevelButton()
    {
        CloseStageClearPanel();
        levelManager.NextLevel();
    }

    /// <summary>
    /// Load same Level
    /// </summary>
    public void RestartButton()
    {
        levelManager.RestartLevel();
    }

    private void CloseStageClearPanel()
    {
        stageCompletedPanel.SetActive(false);
    }



}
